#define Max3DLy 1024
extern byte darkfog[40960];
extern word VertBuf[Max3DLy*16];