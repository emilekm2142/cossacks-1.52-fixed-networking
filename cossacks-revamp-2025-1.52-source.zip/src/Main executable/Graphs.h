void ADDGR(int g,int t,int v,byte c);
void DrawAllGrp();
void CLRGR();