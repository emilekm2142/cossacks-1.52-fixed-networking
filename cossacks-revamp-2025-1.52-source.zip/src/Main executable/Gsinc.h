#include "Arc\GSCSet.h"
extern CGSCset GSFILES;