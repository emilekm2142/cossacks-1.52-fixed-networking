//extern word fmap[256][256];
extern byte fog[8192+1024];
void ProcessFog();
void LoadFog(int);
void ShowFoggedBattle();
void AcceptMiniMap();